package FileManagement;

import java.io.IOException;

public class fileManagerDemonstrator {

	public static void main(String[] args) throws IOException {
	/*
		fileManager fm = new fileManager();
		
		System.out.println("Add three orders: \n");
		
		fm.addOrder(1000000, "cupcake");
		fm.addOrder(1000001, "cakecup");
		fm.addOrder(1000003, "cakecake");
		
		System.out.println("\nAdd another 1000000:");
		
		fm.addOrder(1000000, "cupcake \r\n cupcake2");
		
		System.out.println("\nDoes cupcake exist in 1000000?: " + fm.elementExists(1000000, "cupcake"));
		System.out.println("Does cakecup exist in 1000000?: " + fm.elementExists(1000000, "cakecup"));
		
		System.out.println("\nDoes 1000001 exist?: " + fm.orderExists(1000001));
		System.out.println("Does 1000002 exist?: " + fm.orderExists(1000002));
		
		System.out.println("\nAdd chocolate to the end of 1000000.");
		fm.addToFile(1000000, "chocolate");
		
		System.out.println("\nClear and add chocolate to 1000003.");
		fm.rewriteFile(1000003, "chocolate");
		
		System.out.println("\nClear 1000001.");
		fm.clearFile(1000001);
		*/
	}
}