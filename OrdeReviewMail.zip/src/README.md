# OrdeReview
This is code for a program that allows a user to select the options they want for an order an allows the business owner to review the order if there are custom requirements.
The way that this program works is that it stores the data of the orders in their own .txt file. The names of the .txt files are the order numbers. There is a separate file that holds all of the existing order numbers. That file is used to keep track of the existing orders and previous orders.
