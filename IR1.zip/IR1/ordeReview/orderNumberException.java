package ordeReview;

public class orderNumberException extends RuntimeException {
	public orderNumberException(String errorMessage) {
		super(errorMessage);
	}
}
